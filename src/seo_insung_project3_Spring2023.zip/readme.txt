Name: Insung Seo
Section: 10862
UFL email: insungseo@ufl.edu
System: Mac
Compiler: g++
SFML version: 2.5.1
IDE: CLion
Other notes: None